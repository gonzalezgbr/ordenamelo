"""Top-level package for ordenamelo."""

__version__ = '0.1.1'
