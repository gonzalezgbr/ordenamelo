# __init__.py

"""Paquete de nivel superior de ordenamelo."""

__version__ = '0.1.0'
